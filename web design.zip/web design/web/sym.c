#include<stdio.h>
#include<conio.h>
#include<string.h>

//#define NULL 0
int size=0;

void Display();
void Delete();
int Search(char lab[]);

struct SymbTab
{
 char label[10],symbol[10];
 int addr;
struct SymbTab *next;};
struct SymbTab *first,*last;
void main()
{
 int op,y;
 char la[10];

  int n;
  char l[10], ch;
  clrscr();
  do{
  printf("\n\tEnter the label : ");
  scanf("%s",l);
  n=Search(l);
  if(n==1)
   printf("\n\tThe label exists already in the symbol table\n\tDuplicate can't be inserted");
  else
   {
    struct SymbTab *p;

    strcpy(p->label,l);
    printf("\n\tEnter the symbol : ");
    scanf("%s",p->symbol);
    printf("\n\tEnter the address : ");
    scanf("%d",&p->addr);
    p->next=NULL;
    if(size==0)
     {
      first=p;
      last=p;
     }
    else
     {
      last->next=p;
      last=p;
     }
    size++;
   }
   printf("\n\tLabel inserted\n");
   printf("\n\tDo you want to continue?\n");
   scanf("%c", &ch);
   }while(ch=='y');
  Display();
  Delete();
  getch();
}

void Display()
{
  int i;
  struct SymbTab *p;
  p=first;
  printf("\n\tLABEL\t\tSYMBOL\t\tADDRESS\n");
  for(i=0;i<size;i++)
   {
    printf("\t%s\t\t%s\t\t%d\n",p->label,p->symbol,p->addr);
    p=p->next;
   }
}
int Search(char lab[])
{
 int i,flag=0;
 struct SymbTab *p;
 p=first;
  for(i=0;i<size;i++)
   {
    if(strcmp(p->label,lab)==0)
     flag=1;
    p=p->next;
   }
 return flag;
}

void Delete()
{
  int a;
  char l[10];
  struct SymbTab *p,*q;
  p=first;
  printf("\n\tEnter the label to be deleted : ");
  scanf("%s",l);
  a=Search(l);
  if(a==0)
    printf("\n\tLabel not found\n");
  else
   {
    if(strcmp(first->label,l)==0)
    first=first->next;
    else if(strcmp(last->label,l)==0)
     {
      q=p->next;
      while(strcmp(q->label,l)!=0)
      {
       p=p->next;
       q=q->next;
      }
      p->next=NULL;
      last=p;
     }
    else
     {
      q=p->next;
      while(strcmp(q->label,l)!=0)
      {
       p=p->next;
       q=q->next;
      }
      p->next=q->next;
    }
    size--;
    printf("\n\tAfter Deletion:\n");
    Display();
   }
}